import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import os

def compute_local_variance(img, ksize=3):
    mean = cv2.blur(img, (ksize, ksize))
    squared_mean = cv2.blur(img ** 2, (ksize, ksize))
    variance = squared_mean - mean ** 2
    return variance

def evaf_filter(image, edge_thresh=0.1, var_thresh=500, ksize=3):
    image = image.astype(np.float32)
    sobel_x = cv2.Sobel(image, cv2.CV_32F, 1, 0, ksize=ksize)
    sobel_y = cv2.Sobel(image, cv2.CV_32F, 0, 1, ksize=ksize)
    edge_magnitude = cv2.magnitude(sobel_x, sobel_y)
    edge_mask = edge_magnitude > edge_thresh * edge_magnitude.max()
    variance_map = compute_local_variance(image, ksize)
    high_variance_mask = variance_map > var_thresh
    output = np.copy(image)
    padded = cv2.copyMakeBorder(image, ksize//2, ksize//2, ksize//2, ksize//2, cv2.BORDER_REFLECT)

    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            roi = padded[i:i+ksize, j:j+ksize]
            if edge_mask[i, j] or high_variance_mask[i, j]:
                output[i, j] = np.median(roi)
            else:
                output[i, j] = np.mean(roi)
    return output.astype(np.uint8)

def run_evaf_on_images(input_dir='Images', output_dir='Images/evaf_output', ground_truth_path='Images/barbara.png'):
    os.makedirs(output_dir, exist_ok=True)
    ground_truth = cv2.imread(ground_truth_path, cv2.IMREAD_GRAYSCALE)
    results = []
    for fname in os.listdir(input_dir):
        if fname.startswith('barbara_') and fname.endswith('.png') and 'output' not in fname:
            img_path = os.path.join(input_dir, fname)
            noisy_img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            denoised = evaf_filter(noisy_img)
            out_path = os.path.join(output_dir, f'evaf_{fname}')
            cv2.imwrite(out_path, denoised)
            psnr_val = psnr(ground_truth, denoised)
            ssim_val = ssim(ground_truth, denoised)
            results.append((fname, psnr_val, ssim_val))
            print(f'{fname}: PSNR={psnr_val:.2f}, SSIM={ssim_val:.4f}')
    return results

if __name__ == "__main__":
    run_evaf_on_images()
